# Input Sequence 開發文件

## 專案結構

```text
.
├─ src\InputSequencePlugin.cpp   外掛、解析器、即時預覽與 Win32 視窗
├─ CMakeLists.txt                建置、版本與 CPack 發行設定
├─ install.ps1                   Windows PowerShell 安裝程式
├─ README.md                     使用者文件
└─ release\                     產生的發行 ZIP
```

外掛以 C++17、Win32 API、Notepad++ Plugin API 與 Scintilla 訊息實作，不需要額外執行階段套件。

## 主要流程

1. Notepad++ 呼叫 `setInfo` 提供主視窗與兩個 Scintilla 編輯器控制項。
2. `getFuncsArray` 註冊「輸入連續編號」及「關於 Input Sequence」兩個選單命令。
3. 使用者開啟輸入視窗時，外掛保存原始文件和所有選取範圍。
4. 每次輸入內容改變時，`parseSpec` 解析運算式，並由 `renderPreview` 重新產生預覽。
5. 套用時保留預覽結果；取消時透過 Scintilla undo transaction 還原原始內容。

## 解析規則

- 完整形式為 `<start> <operator> <step> : <digit> : <radix>`。
- `digit`、`radix` 可省略；數字預設 10 進位，英文字母預設 26 進位。
- 數字起始值具有多個前導零且未指定 `digit` 時，前導零長度會成為位數。例如 `000+1` 等同 `0+1:3`。
- `+` 或 `-` 後方存在有效步進值時才視為運算子，否則視為固定尾碼。
- 單引號中的內容為固定字串；位於序列核心之前時是前綴，之後則是尾碼。
- 無序列核心的單引號內容（例如 `'A'`）會原樣套用至所有選取範圍。

## 建置

需求：Windows 10 或更新版本、Visual Studio C++ 工具鏈與 Windows SDK，以及 CMake 3.20 或更新版本。

```powershell
cmake -S . -B build -A x64
cmake --build build --config Release
```

編譯結果位於 `build\Release\InputSequence.dll`。

## 發布

1. 修改 `CMakeLists.txt` 中的 `project(... VERSION x.y.z)`。
2. 完成 Release 建置。
3. 執行 CPack：

```powershell
cpack --config build\CPackConfig.cmake -C Release -B release
```

發行檔位於 `release\NotepadPlusPlusInputSequence-<version>-win64.zip`。

每次功能、修正或文件更新完成後，都應建立新的可安裝版本。發布前至少確認：

- Release 組態可成功編譯。
- DLL 匯出 `setInfo`、`getName`、`getFuncsArray`、`beNotified`、`messageProc`、`isUnicode`。
- ZIP 包含 `plugins\InputSequence\InputSequence.dll` 與 `install.ps1`。
- `install.ps1` 維持 ASCII 相容，確保 Windows PowerShell 5 不會因編碼而解析失敗。

## 作者

- 作者：dasu88
- 電子郵件：dasu88@gmail.com
