param(
    [string]$NotepadPlusPlusPath = ${env:ProgramFiles} + '\Notepad++'
)

$plugin = Join-Path $PSScriptRoot 'plugins\InputSequence\InputSequence.dll'
if (-not (Test-Path -LiteralPath $plugin)) { throw "Plugin file not found: $plugin" }
if (-not (Test-Path -LiteralPath $NotepadPlusPlusPath)) { throw "Notepad++ was not found at: $NotepadPlusPlusPath. Use -NotepadPlusPlusPath to specify its installation folder." }

$destination = Join-Path $NotepadPlusPlusPath 'plugins\InputSequence'
New-Item -ItemType Directory -Force -Path $destination | Out-Null
Copy-Item -LiteralPath $plugin -Destination (Join-Path $destination 'InputSequence.dll') -Force
Write-Host 'Installed. Restart Notepad++, then use Plugins > Input Sequence > Input Sequence.'
